import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Country } from './models/country.model';

@Injectable({
    providedIn: 'root'
})
export class RegionService {
    private baseUrl = 'https://restcountries.eu/rest/v2/region/';
    constructor(private httpService: HttpClient) {

    }
    getCountries(regionName: string): Observable<Country[]> {
        return this.httpService.get<Country[]>(this.baseUrl + regionName);
    }
}