import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { Routes, RouterModule } from '@angular/router';

import { RegionListComponent } from './region-list/region-list.component';

import { HttpClientModule } from '@angular/common/http';

const routes: Routes = [
    { path: '', component: RegionListComponent }
];



@NgModule({
    imports: [
        CommonModule,
        HttpClientModule,
        FormsModule,
        RouterModule.forChild(routes)
    ],
    declarations: [
        RegionListComponent
    ]
})
export class RegionsModule {

}