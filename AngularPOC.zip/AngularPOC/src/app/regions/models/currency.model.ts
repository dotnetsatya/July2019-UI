export interface Currency {
    code: string;
    name: string;
    symbel: string;
}