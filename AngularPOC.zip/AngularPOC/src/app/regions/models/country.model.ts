import { Currency } from './currency.model';
export interface Country {
    name: string;
    population: number;
    flag: string;
    capital: string;
    currencies: Currency[];
}