import { Component, OnInit } from '@angular/core';
import { RegionService } from '../region.service';
import { Country } from '../models/country.model';
@Component({
    selector: 'app-regions',
    templateUrl: './region-list.component.html',
    styleUrls: ['./region-list.component.scss']
})
export class RegionListComponent implements OnInit {

    countries: Country[] = null;
    regions = ['Asia', 'Europe'];
    selectedRegion: null;
    selectedCountry: Country;
    constructor(private regionService: RegionService){

    }


    ngOnInit() {
      
    }

    loadCountries() {
        this.regionService.getCountries(this.selectedRegion).subscribe(response => {
            this.countries = response;
         });
    }
}